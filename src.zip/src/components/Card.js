import * as React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';


export default function Gallary() {
    return (
        <div>
            <div className='flex'>
                    <span id='hk' >MY FAVORITES</span>           
                    <span id='hk1'><img src="https://corretto.qodeinteractive.com/wp-content/uploads/2018/04/title-separator.png" alt="" /></span>           
                    <span id='hk2' >Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                    <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  eiusmod tempor incididunt ut labore et dolore</span>           
            </div>
        <div style={{ display: 'flex', flexDirection: 'row', gap: '5rem' , 	paddingTop:'50px' , paddingLeft:'5px'}}>

       
        <Card sx={{ maxWidth: 380, maxHeight: 420 }}>
          <CardActionArea>
            <CardMedia
              component="img"
              height="200"
              display="block"
              image="https://images.unsplash.com/photo-1497515114629-f71d768fd07c?q=80&w=1484&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
              alt="green iguana"
            />
            <CardContent>
              <Typography gutterBottom variant="h5" component="div">
                Lizard
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Lizards are a widespread group of squamate reptiles, with over 6,000
                species, ranging across all continents except Antarctica
              </Typography>
            </CardContent>
          </CardActionArea>
        </Card>
        

        <Card sx={{ maxWidth: 380, maxHeight: 420 }}>
          <CardActionArea>
            <CardMedia
              component="img"
              height="200"
              display="block"
              image="https://images.unsplash.com/photo-1426260193283-c4daed7c2024?q=80&w=1476&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
              alt="green iguana"
            />
            <CardContent>
              <Typography gutterBottom variant="h5" component="div">
                Lizard
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Lizards are a widespread group of squamate reptiles, with over 6,000
                species, ranging across all continents except Antarctica
              </Typography>
            </CardContent>
          </CardActionArea>
        </Card>



        <Card sx={{ maxWidth: 380, maxHeight: 400 }}>
          <CardActionArea>
            <CardMedia
              component="img"
              height="200"
              display="block"
              image="https://images.unsplash.com/photo-1497636577773-f1231844b336?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
              alt="green iguana"
            />
            <CardContent>
              <Typography gutterBottom variant="h5" component="div">
                Lizard
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Lizards are a widespread group of squamate reptiles, with over 6,000
                species, ranging across all continents except Antarctica
              </Typography>
            </CardContent>
          </CardActionArea>
        </Card>
        {/* Repeat the above Card component for additional cards if needed */}
        
      </div>
      </div>
    );
  }
  