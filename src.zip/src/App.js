import './App.css';
import Home from './components/Home';
// import Sliderbar from './components/slider';
import Gallary from './components/Card';
import Activity from './components/Activity';
// import Header from './components/Header';
function App() {
  return (
    <div className="App">
      <Home></Home>
      <Activity></Activity>
      <Gallary></Gallary>
    </div>
  );
}

export default App;
